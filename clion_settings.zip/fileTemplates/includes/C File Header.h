#set($numberSign = '###   ########')
#set($spaces = ' ')
#set($end = 49 - $FILE_NAME.length())
#set($range = [0..$end])
#foreach($i in $range)
    #set($spaces = "${spaces} ")
#end
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ${FILE_NAME}${spaces}:+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: srythim <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: ${YEAR}/${MONTH}/${DAY} ${HOUR}:${MINUTE}:00 by srythim           #+#    #+#             */
/*   Updated: ${YEAR}/${MONTH}/${DAY} ${HOUR}:${MINUTE}:00 by srythim          ${numberSign}.fr       */
/*                                                                            */
/* ************************************************************************** */

